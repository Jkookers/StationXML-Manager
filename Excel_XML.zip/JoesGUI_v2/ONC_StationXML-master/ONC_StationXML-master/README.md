# ONC_StationXML
StationXML file describing metadata for ONC data hosted by IRIS


Reports generated from code to check the integrity of the StationXML are kept under the reports directory
 * [station-xml-validator-Results.html](http://htmlpreview.github.io/?https://github.com/OceanNetworksCanada/ONC_StationXML/blob/master/reports/station-xml-validator-Results.html)
   * Results from IRIS station-xml-validator
