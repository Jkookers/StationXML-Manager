## -*- coding: utf-8 -*-
#"""
#Created on Tue May 12 16:49:12 2020
#
#@author: jacob
#"""
#
#import matplotlib.pyplot as plt
#import numpy as np
#
#
#degS = u"\u00b0"
##ax = plt.plot(1, polar = True)
##
##ax.plot(0,1)
##ax.arrow(60/180*np.pi,0,0,0.82, width = 0.05, edgecolor = 'black', facecolor = 'blue', lw = 2, zorder = 2)
##ax.set_theta_zero_location("N")
##ax.set_theta_direction(-1)
##ax.set_yticklabels([])
##ax.set_title("Azimuth", pad = 20)
##
##plt.show()
#fig = plt.figure()
#ax1 = fig.add_subplot(121, projection = 'polar')
#ax1.plot(0,1)
#ax1.arrow(60/180*np.pi,0,0,0.82, width = 0.05, edgecolor = 'black', facecolor = 'blue', lw = 2, zorder = 2)
#ax1.set_theta_zero_location("N")
#ax1.set_theta_direction(-1)
#ax1.set_yticklabels([])
#ax1.set_title("Azimuth", pad = 20, size = 18)
#
#ax2 = fig.add_subplot(122, projection = 'polar')
#ax2.plot(0,1)
#ax2.arrow(-50/180*np.pi,0,0,0.82, width = 0.05, edgecolor = 'black', facecolor = 'blue', lw = 2, zorder = 2)
#ax2.set_theta_direction(-1)
#ax2.set_theta_zero_location("E")
#ax2.set_thetamin(-90)
#ax2.set_thetamax(90)
#ax2.set_xticks(np.linspace((-1*(np.pi))/2,(np.pi)/2, 13))
#ax2.set_yticklabels([])
#ax2.set_title("Dip", pad = 20, size = 18)
#ax2.set_xticklabels(['-90'+degS + '\n(Up)','-75'+degS,'-60'+degS,'-45'+degS,'-30'+degS,'-15'+degS,'0'+degS + "\n(Seafloor)",'15'+degS,'30'+degS,'45'+degS,'60'+degS,'75'+degS,'90'+degS +'\n(Down)'], size = 10)
#
#
#test = {1:6,2:7,3:8,4:9}
#
#
#op = ['1','2','3']
#
#y = op[0]
#
#test[1]= 5
#
#sf = 'Code','Latitude','Longitude','Elevation','Start Date (UTC)','Creation Date (UTC)','End Date (UTC)','Site Name','Geology','Description'
#
#for i, j in enumerate(sf):
#    print(str(i)+str(j))
#    
#st = "https://data.oceannetworks.ca/DeviceListing?DeviceId=12345"
#
#r = st.split("=",1)[0]
#
#from tkinter import *
#
#def hallo():
#    test = []
#    for entry in entries:
#        test.append(entry.get())
#    
#    for i in test:
#        print(i)
#    
#root=Tk()
#entries = []
#
#for i in range(10):
#    en = Entry(root)
#    en.grid(row=i+1, column=0)
#    entries.append(en)
#
#
#
#button=Button(root,text="krijg",command=hallo).grid(row=12,column=0)
#
#root.mainloop()

import obspy
from obspy import read_inventory, UTCDateTime, read

from datetime import datetime, timedelta

from obspy.clients.nrl import NRL


dl_resp = read_inventory('C:/Users/jacob/Desktop/JoesGUI_v2/ONC_StationXML-master/ONC_StationXML-master/_sensorRESP/KEMF.EHE.116.xml', format='STATIONXML')[0][0][0].response



from onc.onc import ONC
onc = ONC("ca93adb8-5125-45e0-aecb-a4daf4eb9432")
 
filters = {
    'locationCode':'BPEB',      # A CTD in Burrard Inlet
}
result = onc.getDeployments(filters)
for t in result:
    print(t)
 
onc.print(result)


for x in t:
    for y in x:
        print(y)


t = onc.getDevices({'deviceId' : '24061'})

t1 = {'r': 5}
t2 = {'s': 6}

t1.update(t2)

with open('StationList.txt','r') as stats:
    t = stats.readlines()

t = [x.split() for x in t]

r = t[0][2]
    

tnow = datetime.now()
tnow.strftime("%Y-%m-%dT%H:%M:%S.000Z")

r = tnow - timedelta(minutes = 5)

r = datetime(year = 2020, month = tester, day = 31, hour = 12, minute = 34, second = 56)

from obspy.core.inventory import Inventory, Network, Station, Channel, Site
from obspy import Catalog

inv = read_inventory("NV.xml")

inv[0][0][0].response = None

st = inv.select(station = 'BACME')
ct = inv.select(station = 'KEMF', channel = 'HNE')
ct1 = inv.select(station = 'BACME')
ct2 = ct.remove(station = 'KEMF', location = 'W1', channel = 'HNE')

con = inv[0].get_contents()

tr = [i for i, s in enumerate(con['stations']) if 'KEMO' in s]

t0 = inv[0].stations.index(inv.select('BACME'))

r[0][0].channels.append()

t = ct2.__iadd__(ct1)

now = datetime.now()


sta = Station(
        code = 'NAME',
        latitude = 1,
        longitude = 2,
        elevation = 999,
        creation_date = UTCDateTime(now),
        site = Site(name = "Brand New Station"))

cha = Channel(
        code = "ABC",
        location_code = "",
        latitude = 1,
        longitude = 2,
        elevation = 999,
        depth = 999,
        azimuth = 0,
        dip = -90,
        sample_rate = 999)



sta.channels.append(cha)

st[0].stations.append(sta)

t= sta[0].response

u = None

ct2.

inv.remove(ct)

ct.remove()

st.networksct2

ct2 = ct[0][0][0]

st2 = ct[0][0]





st2.channels.append(ct2)

rt = st[0][0]


nt = n[0][0][0]

gt = n.copy()
gtr = gt[0][0][0].response

n = gt.get_contents()

g = any('ENHR' in t for t in n['stations'])

t = None

r = UTCDateTime(None).day

s = inv[0][0]

test1 = inv.select(station = 'BACND', location = 'Z1', channel = 'BNE',starttime = '2018-06-22T03:00:00.000000Z', endtime = 'None')
test2 = test1.copy()

nrl = NRL()

t = 1
l = []
t1 = nrl.sensors


t = inv[0][1][24]
t1 = inv[0][1][2]

while t == 1:
    
    print(t1)
    s = input("get sensor: ")
    l.append(s)
    t2 = t1[s]
    t1 = t2
    
    if type(t2) == tuple:
        print('Hi Mom')


l = list(nrl.sensors)

t = nrl.dataloggers['Guralp']['']
t1 = nrl.sensors['Guralp']['CMG-1T']['360 s - 50 Hz']

r = nrl.get_response(sensor_keys = ['Guralp','CMG-1T','360 s - 50 Hz','1500'],
                     datalogger_keys = ['Guralp','CMG-DM24','Mk3','Fixed','31-40','38','1000'])

inv = read_inventory()
t = obspy

jl = UTCDateTime(2001, 1, 1, 0, 0, 0)
kl = UTCDateTime(2002, 1, 1, 0, 0, 0)

t = read_inventory('RESP_file_110_Magnetom_MFN.txt', format = 'RESP')


inv = Inventory(
    # We'll add networks later.
    networks=[],
    # The source should be the id whoever create the file.
    source="ObsPy-Tutorial")

net = Network(
    # This is the network code according to the SEED standard.
    code="XX",
    # A list of stations. We'll add one later.
    stations=[],
    description="A test stations.",
    # Start-and end dates are optional.
    start_date=obspy.UTCDateTime(2016, 1, 2))

sta = Station(
    # This is the station code according to the SEED standard.
    code="ABC",
    latitude=1.0,
    longitude=2.0,
    elevation=345.0,
    creation_date=obspy.UTCDateTime(2016, 1, 2),
    site=Site(name="First station"))

cha = Channel(
    # This is the channel code according to the SEED standard.
    code="HHZ",
    # This is the location code according to the SEED standard.
    location_code="",
    # Note that these coordinates can differ from the station coordinates.
    latitude=1.0,
    longitude=2.0,
    elevation=345.0,
    depth=10.0,
    azimuth=0.0,
    dip=-90.0,
    sample_rate=200)

sta.channels.append(cha)
net.stations.append(sta)
inv.networks.append(net)