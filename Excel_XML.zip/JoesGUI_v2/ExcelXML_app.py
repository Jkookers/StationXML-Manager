# -*- coding: utf-8 -*-
"""
Created on Fri May  8 16:38:03 2020

Modifications of Joe's StationXML to make it more user friendly.

@author: jacob
"""
import os
import tkinter as tk
import tkinter.ttk as ttk
import tkinter.messagebox as tkm
import tkinter.simpledialog as tks
import tkinter.filedialog as tkf
import tkinter.font as tkfont
import time

import obspy
from obspy import read_inventory, UTCDateTime
from datetime import datetime
from obspy.clients.nrl import NRL

from obspy.core.inventory import Inventory, Network, Station, Channel, Site, Equipment
from obspy.core.inventory.util import ExternalReference

import matplotlib
matplotlib.use('TkAgg')

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt

import numpy as np


class ExcelXML(object):
    
    def __init__ (self, inventory_path):
        self.root = tk.Tk()
        self.nrl = NRL()
        
        
        #   Get the size of the workplace to match maximum screen size
        w, h = self.root.maxsize()
        self.version = "1.1.0"
        self.root.title(string = "Inventory Manager {}".format(self.version))
        
        self.dw = w
        self.dh = h
        
        self.var1 = tk.IntVar()
        self.var1.set(0)
        
        fst = tkfont.Font(family = "Lucida Grande", size = 16, underline = 1)
        fsb = tkfont.Font(family = "Lucida Grande", size = 14)
        

        
        #   Create main app layout
        os.makedirs("_bin", exist_ok = True)
        os.makedirs("_Inventories", exist_ok = True)
        os.makedirs("_sensorRESP", exist_ok = True)
        os.makedirs("_dataloggerRESP", exist_ok = True)
        self.inventory_path = ""
        
        #   Empty Variables
        self.workingInv = None
        self.statWork = None
        self.chanWork = None
        self.treeTitle = tk.StringVar()
        self.treeTitle.set("No Inventory Selected")
        
        self.degS = u"\u00b0"
        
        #   Empty Variables - Stat Widget
        
        self.respLab = tk.StringVar()
        self.respLab.set('None')
        self.sentv1 = tk.StringVar()
        self.sentv2 = tk.StringVar()              
        self.sentv3 = tk.StringVar()                
        self.sentv4 = tk.StringVar()
        self.sentv5 = tk.StringVar()                               
        self.sentv6 = tk.StringVar()
        
        self.sdentv1y = tk.StringVar()
        self.sdentv1m = tk.StringVar()
        self.sdentv1d = tk.StringVar()
        self.sdentv1H = tk.StringVar()
        self.sdentv1M = tk.StringVar()
        self.sdentv1S = tk.StringVar()
        
        self.sdentv2y = tk.StringVar()
        self.sdentv2m = tk.StringVar()
        self.sdentv2d = tk.StringVar()
        self.sdentv2H = tk.StringVar()
        self.sdentv2M = tk.StringVar()
        self.sdentv2S = tk.StringVar()
        
        self.sdentv3y = tk.StringVar()
        self.sdentv3m = tk.StringVar()
        self.sdentv3d = tk.StringVar()
        self.sdentv3H = tk.StringVar()
        self.sdentv3M = tk.StringVar()
        self.sdentv3S = tk.StringVar()
        
        self.centv1 = tk.StringVar()
        self.centv2 = tk.StringVar()
        self.centv3 = tk.StringVar()
        self.centv4 = tk.StringVar()
        self.centv5 = tk.StringVar()
        self.centv6 = tk.StringVar()
        self.centv7 = tk.StringVar()
        self.centv8 = tk.StringVar()
        self.centv9 = tk.StringVar()
        self.centv10 = tk.StringVar()
        self.centv11 = tk.StringVar()
        self.centv12 = tk.StringVar()
        self.centv13 = tk.StringVar()
        self.centv14 = tk.StringVar()
        self.centv15 = tk.StringVar()
        
        self.cdentv1y = tk.StringVar()
        self.cdentv1m = tk.StringVar()
        self.cdentv1d = tk.StringVar()
        self.cdentv1H = tk.StringVar()
        self.cdentv1M = tk.StringVar()
        self.cdentv1S = tk.StringVar()
        
        self.cdentv2y = tk.StringVar()
        self.cdentv2m = tk.StringVar()
        self.cdentv2d = tk.StringVar()
        self.cdentv2H = tk.StringVar()
        self.cdentv2M = tk.StringVar()
        self.cdentv2S = tk.StringVar()
        
        #   Get the main directory of the application
        self.curdir = os.getcwd()
        self.create_menubar()
        
        
        #   Create the tree
        def channelSelect(event):
            try:
                r = availTree.item(availTree.identify("item",event.x, event.y))
                print('sfdasdfasdf')
                #   Make a temporary inventory to track changes
                tempWork = self.workingInv.select(station = r['values'][3],
                                                  channel = r['values'][12],
                                                  location = r['values'][13],
                                                  starttime = UTCDateTime(r['values'][28]))
                
                #   Get the station/channel number in the list
                lstr = self.workingInv[0].get_contents()
                self.tcon = [i for i, s in enumerate(lstr['stations']) if r['values'][3] in s]
                
                self.chanWork = tempWork
                
                tempWork2 = self.workingInv.select(station = r['values'][3])                
                self.statWork = tempWork2
                
                lcha = self.statWork[0].get_contents()
                self.tcha = [i for i, s in enumerate(lcha['channels']) if r['values'][12] in s]
                

                if r['values'][27] != 'None':
                    self.respLab.set('Response Present')
                    print('here4')
                else:
                    self.respLab.set('NO RESPONSE!')

                
                self.sentv1.set(r['values'][3])
                self.sentv2.set(r['values'][4])                
                self.sentv3.set(r['values'][5])                
                self.sentv4.set(r['values'][6])
                self.sentv5.set(r['values'][7])                                
                self.sentv6.set(r['values'][8])
                
                #   Dates - Creation
                try: 
                    self.sdentv1y.set(UTCDateTime(r['values'][9]).year)
                    self.sdentv1m.set(UTCDateTime(r['values'][9]).month)
                    self.sdentv1d.set(UTCDateTime(r['values'][9]).day)
                    self.sdentv1H.set(UTCDateTime(r['values'][9]).hour)
                    self.sdentv1M.set(UTCDateTime(r['values'][9]).minute)
                    self.sdentv1S.set(UTCDateTime(r['values'][9]).second)
                except:
                    self.sdentv1y.set('2599')
                    self.sdentv1m.set('12')
                    self.sdentv1d.set('31')
                    self.sdentv1H.set('23')
                    self.sdentv1M.set('59')
                    self.sdentv1S.set('59')
                
                #   Dates - Start
                try:
                    self.sdentv2y.set(UTCDateTime(r['values'][10]).year)
                    self.sdentv2m.set(UTCDateTime(r['values'][10]).month)
                    self.sdentv2d.set(UTCDateTime(r['values'][10]).day)
                    self.sdentv2H.set(UTCDateTime(r['values'][10]).hour)
                    self.sdentv2M.set(UTCDateTime(r['values'][10]).minute)
                    self.sdentv2S.set(UTCDateTime(r['values'][10]).second)
                except:
                    self.sdentv2y.set('2599')
                    self.sdentv2m.set('12')
                    self.sdentv2d.set('31')
                    self.sdentv2H.set('23')
                    self.sdentv2M.set('59')
                    self.sdentv2S.set('59')
                
                #   Dates - end
                try:
                    self.sdentv3y.set(UTCDateTime(r['values'][11]).year)
                    self.sdentv3m.set(UTCDateTime(r['values'][11]).month)
                    self.sdentv3d.set(UTCDateTime(r['values'][11]).day)
                    self.sdentv3H.set(UTCDateTime(r['values'][11]).hour)
                    self.sdentv3M.set(UTCDateTime(r['values'][11]).minute)
                    self.sdentv3S.set(UTCDateTime(r['values'][11]).second)
                except:
                    self.sdentv3y.set('2599')
                    self.sdentv3m.set('12')
                    self.sdentv3d.set('31')
                    self.sdentv3H.set('23')
                    self.sdentv3M.set('59')
                    self.sdentv3S.set('59')
                
                
                self.centv1.set(r['values'][12])
                self.centv2.set(r['values'][13])
                self.centv3.set(r['values'][14])
                self.centv4.set(r['values'][15])
                self.centv5.set(r['values'][16])
                self.centv6.set(r['values'][17])
                self.centv7.set(r['values'][18])
                self.centv8.set(r['values'][19])
                self.centv9.set(r['values'][20])
                self.centv10.set(r['values'][21])
                self.centv11.set(r['values'][22])
                self.centv12.set(r['values'][23])
                self.centv13.set(r['values'][24])
                self.centv14.set(r['values'][25])
                self.centv15.set(r['values'][26])
                
                #   Date - Channels
                #   Date Start
                try:
                    self.cdentv1y.set(UTCDateTime(r['values'][28]).year)
                    self.cdentv1m.set(UTCDateTime(r['values'][28]).month)
                    self.cdentv1d.set(UTCDateTime(r['values'][28]).day)
                    self.cdentv1H.set(UTCDateTime(r['values'][28]).hour)
                    self.cdentv1M.set(UTCDateTime(r['values'][28]).minute)
                    self.cdentv1S.set(UTCDateTime(r['values'][28]).second)
                except:
                    self.cdentv1y.set('2599')
                    self.cdentv1m.set('12')
                    self.cdentv1d.set('31')
                    self.cdentv1H.set('23')
                    self.cdentv1M.set('59')
                    self.cdentv1S.set('59')
               
                #   Date End
                try:
                    self.cdentv2y.set(UTCDateTime(r['values'][29]).year)
                    self.cdentv2m.set(UTCDateTime(r['values'][29]).month)
                    self.cdentv2d.set(UTCDateTime(r['values'][29]).day)
                    self.cdentv2H.set(UTCDateTime(r['values'][29]).hour)
                    self.cdentv2M.set(UTCDateTime(r['values'][29]).minute)
                    self.cdentv2S.set(UTCDateTime(r['values'][29]).second)
                except:
                    self.cdentv2y.set('2599')
                    self.cdentv2m.set('12')
                    self.cdentv2d.set('31')
                    self.cdentv2H.set('23')
                    self.cdentv2M.set('59')
                    self.cdentv2S.set('59')
                
                #   Generate Azimuth/dip plots
                plt.clf()
                ax1 = fig.add_subplot(121, projection = 'polar')
                ax1.plot(0,1)
                ax1.arrow(float(r['values'][18])/180*np.pi,0,0,0.82, 
                          width = 0.05, edgecolor = 'black', facecolor = 'blue', lw = 2, zorder = 2)
                ax1.set_theta_zero_location("N")
                ax1.set_theta_direction(-1)
                ax1.set_yticklabels([])
                ax1.set_title("Azimuth", pad = 20, size = 18)
                
                ax2 = fig.add_subplot(122, projection = 'polar')
                ax2.plot(0,1)
                ax2.arrow(float(r['values'][19])/180*np.pi,0,0,0.82,
                          width = 0.05, edgecolor = 'black', facecolor = 'blue', lw = 2, zorder = 2)
                ax2.set_theta_direction(-1)
                ax2.set_theta_zero_location("E")
                ax2.set_thetamin(-90)
                ax2.set_thetamax(90)
                ax2.set_xticks(np.linspace((-1*(np.pi))/2,(np.pi)/2, 13))
                ax2.set_yticklabels([])
                ax2.set_title("Dip", pad = 20, size = 18)
                ax2.set_xticklabels(['-90'+self.degS + '\n(Up)','-75'+self.degS,'-60'+self.degS,'-45'+self.degS,'-30'+self.degS,'-15'+self.degS,'0'+self.degS + "\n(Seafloor)",'15'+self.degS,'30'+self.degS,'45'+self.degS,'60'+self.degS,'75'+self.degS,'90'+self.degS +'\n(Down)'], size = 10)
                fig.canvas.draw()
            except:
                return
        
        #   Basic elements
        activeTree = tk.Frame(self.root, width = int(w*0.5), height = int(h*0.3))
        activeTree.grid(row = 0, column = 0, rowspan = 2, padx = 5, pady = 5, sticky = "w")
        activeTree.grid_propagate(0)        
        tk.Label(activeTree, textvariable = self.treeTitle, font = fst).grid(row = 0, column = 0, padx = 5, pady = 5, sticky = "w")
        
        availTree = ttk.Treeview(activeTree, selectmode = 'browse')
        availTree.grid(row = 1, column = 0, sticky = "nsew")
        
        #   Create scroll bars
        vsb = ttk.Scrollbar(activeTree, orient = "vertical", command = availTree.yview)
        vsb.grid(row = 1, column = 1, sticky = "nse")
        
        hsb = ttk.Scrollbar(activeTree, orient = "horizontal", command = availTree.xview)
        hsb.grid(row = 2, column = 0, sticky = "ews")
        
        availTree.configure(yscrollcommand = vsb.set)
        availTree.configure(xscrollcommand = hsb.set)
        
        #   Define treeview headers
        availTree["columns"] = ("1","2","3")
        availTree.column("#0", width = int(w*0.45)//4, minwidth = int(w*0.45)//4, stretch = tk.NO)
        availTree.column("1", width = int(w*0.45)//4, minwidth = int(w*0.45)//4, stretch = tk.NO)
        availTree.column("2", width = int(w*0.45)//4, minwidth = int(w*0.45)//4, stretch = tk.NO)
        availTree.column("3", width = int(w*0.45)//4, minwidth = int(w*0.45)//4, stretch = tk.NO)
        
        availTree.heading("#0", text = "Code", anchor = tk.CENTER)
        availTree.heading("1", text = "Location Code", anchor = tk.CENTER)
        availTree.heading("2", text = "Start Time (UTC)", anchor = tk.CENTER)
        availTree.heading("3", text = "End Time (UTC)", anchor = tk.CENTER)

        def change_tree(*args):
            if self.var1 != 0:
                for i in availTree.get_children():
                    availTree.delete(i)
                
                cd = self.workingInv.networks[0].code
                start = str(self.workingInv.networks[0].start_date)
                end = str(self.workingInv.networks[0].end_date)
                
                
                
                self.treeTitle.set("Inventory for: " + cd + ". From: " + start + " to " + end)
                stcnt = 0
                chcnt = 0
                
                for station in self.workingInv.networks[0].stations:
                    stat = availTree.insert("", stcnt, text = station.code, values = ("", str(station.start_date), str(station.end_date)))
                    stcnt += 1
                    chcnt = 0
                    for chan in station.channels:
                        #   Channel description - sensor
                        try:
                            chanD = chan.equipments[0].description
                            try:
                                chanD = chan.equipments[0].description.split('/',1)[0]
                            except:
                                chanD = chan.equipments[0].description
                        except:
                            chanD = None
                            
                        #   Channel description - datalogger
                        try:
                            datD = chan.equipments[0].description
                            try:
                                datD = chan.equipments[0].description.split('/',1)[1]
                            except:
                                datD = chan.equipments[0].description
                        except:
                            chanD = None
                        
                        #   Equipment Serial - sensor
                        try:
                            chanSerial = chan.equipments[0].serial_number
                            try:
                                chanSerial = chan.equipments[0].serial_number.split('/',1)[0]
                            except:
                                chanSerial = chan.equipments[0].serial_number
                        except:
                            chanSerial = None
                            
                        #   Equipment Serial - datalogger
                        try:
                            datSerial = chan.equipments[0].serial_number
                            try:
                                datSerial = chan.equipments[0].serial_number.split('/',1)[1]
                            except:
                                datSerial = chan.equipments[0].serial_number
                        except:
                            datSerial = None
                            
                        #   External reference/DeviceID
                        try:
                            devID = chan.external_references[1].uri.split("=",1)[1]
                        except:
                            devID = None
                            
                        #   separate datalogger/sensor serials
                        try:
                            devID = chan.external_references[1].uri.split("=",1)[1]
                        except:
                            devID = None
                        
                        availTree.insert(stat, "end",
                                         text = chan.code,
                                         values = (chan.location_code,      #0
                                                   chan.start_date,         #1
                                                   chan.end_date,           #2
                                                   station.code,            #3
                                                   station.latitude,        #4
                                                   station.longitude,       #5
                                                   station.elevation,       #6
                                                   station.site.name,       #7
                                                   station.description,     #8
                                                   station.creation_date,   #9
                                                   station.start_date,      #10
                                                   station.end_date,        #11
                                                   chan.code,               #12
                                                   chan.location_code,      #13
                                                   chan.latitude,           #14
                                                   chan.longitude,          #15
                                                   chan.elevation,          #16
                                                   chan.depth,              #17
                                                   chan.azimuth,            #18
                                                   chan.dip,                #19
                                                   chan.types[0],           #20
                                                   chan.sample_rate,        #21
                                                   chanD,                   #22
                                                   datD,                    #23
                                                   chanSerial,              #24
                                                   datSerial,               #25
                                                   devID,                   #26
                                                   chan.response,           #27
                                                   chan.start_date,         #28
                                                   chan.end_date))          #29
                        chcnt += 1
                        save.configure(state = 'normal')
        
        def saver():
            #   Get all values with update regarding the station
            tempSCo = self.sentv1.get()
            tempLat = self.sentv2.get()
            tempLon = self.sentv3.get()
            tempEle = self.sentv4.get()
            tempSit = self.sentv5.get()                               
            tempDec = self.sentv6.get()
            
            temp1y = self.sdentv1y.get()
            temp1m = self.sdentv1m.get()
            temp1d = self.sdentv1d.get()
            temp1H = self.sdentv1H.get()
            temp1M = self.sdentv1M.get()
            temp1S = self.sdentv1S.get()
            
            temp2y = self.sdentv2y.get()
            temp2m = self.sdentv2m.get()
            temp2d = self.sdentv2d.get()
            temp2H = self.sdentv2H.get()
            temp2M = self.sdentv2M.get()
            temp2S = self.sdentv2S.get()
            
            temp3y = self.sdentv3y.get()
            temp3m = self.sdentv3m.get()
            temp3d = self.sdentv3d.get()
            temp3H = self.sdentv3H.get()
            temp3M = self.sdentv3M.get()
            temp3S = self.sdentv3S.get()
            
            #   Get all values with update regarding the channel
            tempCCo = self.centv1.get()
            tempLCo = self.centv2.get()
            tempCLa = self.centv3.get()
            tempCLo = self.centv4.get()
            tempCEl = self.centv5.get()
            tempCDe = self.centv6.get()
            tempCAz = self.centv7.get()
            tempCDi = self.centv8.get()
            tempCIT = self.centv9.get()
            tempCHz = self.centv10.get()
            tempCSD = self.centv11.get()
            tempCDD = self.centv12.get()
            tempCSN = self.centv13.get()
            tempCDN = self.centv14.get()
            tempDev = self.centv15.get()
            
            print(tempCAz)
            
            temp4y = self.cdentv1y.get()
            temp4m = self.cdentv1m.get()
            temp4d = self.cdentv1d.get()
            temp4H = self.cdentv1H.get()
            temp4M = self.cdentv1M.get()
            temp4S = self.cdentv1S.get()
            
            temp5y = self.cdentv2y.get()
            temp5m = self.cdentv2m.get()
            temp5d = self.cdentv2d.get()
            temp5H = self.cdentv2H.get()
            temp5M = self.cdentv2M.get()
            temp5S = self.cdentv2S.get()
            
            #   Checks the station entries
            #   Station Code
            if (' ' in tempSCo) or (tempSCo == None) or len(tempSCo) > 5:
                tkm.showwarning(title = "Station - Invalid Entry", message = "Invalid Station Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                return
            #   Location
            try:
                tempLat2 = float(tempLat)
                tempLon2 = float(tempLon)
                if (-90 <= tempLat2 <= 90) != True:
                    tkm.showwarning(title = "Station - Invalid Entry", message = "Invalid Latitude Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                    return
                if (-180 <= tempLat2 <= 180) != True:
                    tkm.showwarning(title = "Station - Invalid Entry", message = "Invalid Longitude Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                    return
            except:
                tkm.showwarning(title = "Station - Invalid Entry", message = "Invalid Location Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                return
            
            #   Elevation
            try:
                tempEle2 = float(tempEle)
            except:
                tkm.showwarning(title = "Station - Invalid Entry", message = "Invalid Location Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                return
            
            #   Creation Date
            try:
                credate = UTCDateTime(int(temp1y),int(temp1m),int(temp1d),int(temp1H),int(temp1M),int(temp1S))
            except:
                tkm.showwarning(title = "Station - Invalid Entry", message = "Invalid Creation Date Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                return
            
            #   Start Date
            try:
                stadate = UTCDateTime(int(temp2y),int(temp2m),int(temp2d),int(temp2H),int(temp2M),int(temp2S))
            except:
                tkm.showwarning(title = "Station - Invalid Entry", message = "Invalid Start Date Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                return
            
            #   End Date
            try:
                enddate = UTCDateTime(int(temp3y),int(temp3m),int(temp3d),int(temp3H),int(temp3M),int(temp3S))
            except:
                tkm.showwarning(title = "Station - Invalid Entry", message = "Invalid End Date Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                return
            
            #   Generates a temporary station based on info update
            try:
                upstat = Station(
                        code = tempSCo.upper(),
                        latitude = tempLat2,
                        longitude = tempLon2,
                        elevation = tempEle2,
                        description = tempDec,
                        creation_date = credate,
                        site = Site(name = tempSit),
                        start_date = stadate,
                        end_date = enddate)
            except:
                tkm.showwarning(title = "Invalid Station", message = "Invalid Station Creation.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                return
            
            #   Checks channel information
            #   Channel code
            if (' ' in tempCCo) or (tempCCo == None) or len(tempCCo) > 3:
                tkm.showwarning(title = "Channel - Invalid Entry", message = "Invalid Station Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                return
                    
            #   Azimuth/dip
            try:
                az = float(tempCAz)
                di = float(tempCDi)
                if (0 <= az <= 360) != True:
                    tkm.showwarning(title = "Channel - Invalid Entry", message = "Invalid Azimuth Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                    return
                if (-90 <= di <= 90) != True:
                    tkm.showwarning(title = "Channel - Invalid Entry", message = "Invalid Dip Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                    return
            except:
                tkm.showwarning(title = "Channel - Invalid Entry", message = "Invalid Azimuth or Dip Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                return 
            
            #   Channel code naming check
            #   Get the end of the channel name
            charac = tempCCo[-1]
            
            if charac == 'N':
                if (5 < az < 355) == True:
                    ask = tkm.askyesno(title = "Channel - Invalid Entry", message = "Azimuth Doesn't Match North Channel Name based on SEED Guidlines.\nDo you wish to continue?", parent = self.root, icon = "warning")
                    if ask == False:
                        return
            
            if charac == 'E':
                if (85 < az < 95) == False:
                    ask = tkm.askyesno(title = "Channel - Invalid Entry", message = "Azimuth Doesn't Match East Channel Name based on SEED Guidlines.\nDo you wish to continue?", parent = self.root, icon = "warning")
                    if ask == False:
                        return
                    
            if charac == 'Z':
                if (-85 < az < 85) == True:
                    ask = tkm.askyesno(title = "Channel - Invalid Entry", message = "Dip Doesn't Match Vertical Channel Name based on SEED Guidlines.\nDo you wish to continue?", parent = self.root, icon = "warning")
                    if ask == False:
                        return        
                
            
            #   Location Code
            if (' ' in tempLCo) or (tempLCo == None) or len(tempLCo) > 2:
                tkm.showwarning(title = "Channel - Invalid Entry", message = "Invalid Station Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                return
            
            #   Location
            try:
                tempLat3 = float(tempCLa)
                tempLon3 = float(tempCLo)
                if (-90 <= tempLat3 <= 90) != True:
                    tkm.showwarning(title = "Channel - Invalid Entry", message = "Invalid Latitude Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                    return
                if (-180 <= tempLon3 <= 180) != True:
                    tkm.showwarning(title = "Channel - Invalid Entry", message = "Invalid Longitude Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                    return
            except:
                tkm.showwarning(title = "Channel - Invalid Entry", message = "Invalid Location Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                return 
            
            #   Elevation
            try:
                tempEle3 = float(tempCEl)
            except:
                tkm.showwarning(title = "Channel - Invalid Entry", message = "Invalid Location Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                return
            
            #   Depth
            try:
                dep3 = float(tempCDe)
            except:
                tkm.showwarning(title = "Channel - Invalid Entry", message = "Invalid Location Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                return
            
            #   Sample rate
            try:
                samp = float(tempCHz)
                if samp < 0:
                    tkm.showwarning(title = "Channel - Invalid Entry", message = "Invalid Sample Rate Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                    return
            except:
                tkm.showwarning(title = "Channel - Invalid Entry", message = "Invalid Sample Rate Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
               
            #   Combine sensor/datalogger descriptions and serial numbers
            sendatDesc = tempCSD + '/' + tempCDD
            sendatNumb = tempCSN + '/' + tempCDN
            
            #   Generate the URL for the deviceID
            try:
                devID = str(int(tempDev))
                urlExt = 'https://data.oceannetworks.ca/DeviceListing?DeviceId=' + devID
            except:
                tkm.showwarning(title = "Channel - Invalid Entry", message = "Invalid Device ID Entry.\nPlease follow ONC Device ID Naming Scheme", parent = self.root, icon = "warning")
                return
            
            #   Start Date
            try:
                stadate4 = UTCDateTime(int(temp4y),int(temp4m),int(temp4d),int(temp4H),int(temp4M),int(temp4S))
            except:
                tkm.showwarning(title = "Channel - Invalid Entry", message = "Invalid Start Date Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                return
            
            #   End Date
            try:
                enddate5 = UTCDateTime(int(temp5y),int(temp5m),int(temp5d),int(temp5H),int(temp5M),int(temp5S))
            except:
                tkm.showwarning(title = "Channel - Invalid Entry", message = "Invalid End Date Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                return
            
            try:
                upchan = Channel(
                            code = tempCCo.upper(),
                            location_code = tempLCo.upper(),
                            latitude = tempLat3,
                            longitude = tempLon3,
                            elevation = tempEle3,
                            depth = dep3,
                            start_date = stadate4,
                            end_date = enddate5,
                            azimuth = az,
                            dip = di,
                            sample_rate = samp,
                            types = [tempCIT.upper()],
                            equipments = Equipment(description = sendatDesc,
                                                   serial_number = sendatNumb),
                            sensor = Equipment(description = sendatDesc,
                                               serial_number = sendatNumb),
                            external_references = [ExternalReference('https://data.oceannetworks.ca/DataSearch?location=' + upstat.code, 'Data Search URL.'),
                                                   ExternalReference(urlExt, 'Device URL.')])
            except:
                tkm.showwarning(title = "Invalid Channel", message = "Invalid Channel Creation.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                return
            
            
            #   Check if station is new or matches existing stations
            getstatAll = self.workingInv.get_contents()
            getstatWrk = self.chanWork.get_contents()
            getchanAll = self.statWork.get_contents()
            
            locChan = '.' + upchan.location_code + '.' + upchan.code
            
            print('prior save')
            #   If there were slight changes to the specific channel. Maintain response file
            if any(upstat.code in name for name in getstatWrk['stations']) == True:
                print('if 1 save start')
                if any(locChan in name for name in getstatWrk['channels']) == True:
                    print('if 2 save start')
                    prevResp = self.chanWork[0][0][0].response
                    upchan.response = prevResp
                    self.chanWork[0][0][0].channel = upchan.code
                    self.chanWork[0][0][0].location_code = upchan.location_code
                    self.chanWork[0][0][0].latitude = upchan.latitude
                    self.chanWork[0][0][0].longitude = upchan.longitude
                    self.chanWork[0][0][0].elevation = upchan.elevation
                    self.chanWork[0][0][0].depth = upchan.depth
                    self.chanWork[0][0][0].start_date = upchan.start_date
                    self.chanWork[0][0][0].end_date = upchan.end_date
                    self.chanWork[0][0][0].azimuth = upchan.azimuth
                    self.chanWork[0][0][0].dip = upchan.dip
                    self.chanWork[0][0][0].sample_rate = upchan.sample_rate
                    self.chanWork[0][0][0].types = upchan.types
                    self.chanWork[0][0][0].equipments = upchan.equipments
                    self.chanWork[0][0][0].sensor = upchan.sensor
                    self.chanWork[0][0][0].external_references = upchan.external_references
                    self.var1.set(self.var1.get()+1)

#                    self.workingInv[0][0].channels.append(upchan)
                    print('if 2 save end')
                    return
                elif any(locChan in name for name in getstatWrk['channels']) == False:
                    print('elif 1 save start')
                    if any(locChan in name for name in getchanAll['channels']) == True:
                        print('if 2 save start')
                        ask = tkm.askyesno(title = "Matching Channel", message = "Channel Matches " + upstat.code + locChan + '.\nDo you wish to overwrite? If No, Channel will be appended to station.', parent = self.root, icon = "warning")
                        if ask == True:
                            print('Overwrite channel start')
                            prevResp = self.chanWork[0][0][0].response
                            upchan.response = prevResp
                            self.chanWork[0][0][0].channel = upchan.code
                            self.chanWork[0][0][0].location_code = upchan.location_code
                            self.chanWork[0][0][0].latitude = upchan.latitude
                            self.chanWork[0][0][0].longitude = upchan.longitude
                            self.chanWork[0][0][0].elevation = upchan.elevation
                            self.chanWork[0][0][0].depth = upchan.depth
                            self.chanWork[0][0][0].start_date = upchan.start_date
                            self.chanWork[0][0][0].end_date = upchan.end_date
                            self.chanWork[0][0][0].azimuth = upchan.azimuth
                            self.chanWork[0][0][0].dip = upchan.dip
                            self.chanWork[0][0][0].sample_rate = upchan.sample_rate
                            self.chanWork[0][0][0].types = upchan.types
                            self.chanWork[0][0][0].equipments = upchan.equipments
                            self.chanWork[0][0][0].sensor = upchan.sensor
                            self.chanWork[0][0][0].external_references = upchan.external_references
                            self.var1.set(self.var1.get()+1)
                            print('overwrite channel end')
                            return
                        elif ask == False:
                            prevResp = self.chanWork[0][0][0].response
                            upchan.response = prevResp
                            self.workingInv[0][self.tcon[0]].channels.append(upchan)
                            self.var1.set(self.var1.get()+1)
                            return
                    elif any(locChan in name for name in getchanAll['channels']) == False:
                        prevResp = self.chanWork[0][0][0].response
                        upchan.response = prevResp
                        self.workingInv[0][self.tcon[0]].channels.append(upchan)
                        self.var1.set(self.var1.get()+1)
                        return
            elif any(upstat.code in name for name in getstatWrk['stations']) == False:
                print('elif 2 save station')
                if any(upstat.code in name for name in getstatAll['stations']) == False:
                    print('append station start')
                    prevResp = self.chanWork[0][0][0].response
                    upchan.response = prevResp
                    upstat.channels.append(upchan)
                    self.workingInv[0].stations.append(upstat)
                    self.var1.set(self.var1.get()+1)
                    print('append station end')
                    return
                elif any(upstat.code in name for name in getstatAll['stations']) == True:
                    print('station error')
                    tkm.showwarning(title = "Station Save Error", message = "The station name provided overwrites a previously existing station.\nTo avoid overwriting another station, please change the station name.", parent = self.root, icon = "warning")
                    return
                
                
                
                
                

        #   Stats Frame
        availTree.bind('<1>', channelSelect)
        self.var1.trace('w', change_tree)
        
        stationInfo = tk.Frame(self.root)
        stationInfo.grid(row = 0, column = 1, padx = 5, pady = 5, sticky = "w")
        
        stationInfoDates = tk.Frame(self.root)
        stationInfoDates.grid(row = 1, column = 1, sticky = "w")
        
        channelInfo = tk.Frame(self.root)
        channelInfo.grid(row = 2, column = 1, padx = 5, pady = 5, sticky = "w")
        
        channelInfoDates = tk.Frame(self.root)
        channelInfoDates.grid(row = 3, column = 1, sticky = "w")
        
        #   Station/channels information labels
        ttk.Label(stationInfo, width = 12, text = "Station Info", font = fst).grid(row = 0, column = 0, padx = 5, sticky = "w")
        ttk.Label(stationInfo, width = 12, text = "Code: ", font = fsb).grid(row = 1, column = 0, padx = 5, sticky = "w")
        ttk.Label(stationInfo, width = 12, text = "Latitude ("+ self.degS + "): ", font = fsb).grid(row = 2, column = 0, padx = 5, sticky = "w")
        ttk.Label(stationInfo, width = 12, text = "Longitude ("+ self.degS + "): ", font = fsb).grid(row = 3, column = 0, padx = 5, sticky = "w")
        ttk.Label(stationInfo, width = 12, text = "Elevation (m): ", font = fsb).grid(row = 4, column = 0, padx = 5, sticky = "w")
        ttk.Label(stationInfo, width = 12, text = "Site: ", font = fsb).grid(row = 5, column = 0, padx = 5, sticky = "w")
        ttk.Label(stationInfo, width = 12, text = "Description: ", font = fsb).grid(row = 6, column = 0, padx = 5, sticky = "w")
        ttk.Label(stationInfoDates, width = 12, text = "Creation Date: ", font = fsb).grid(row = 7, column = 0, padx = 5, sticky = "w")
        ttk.Label(stationInfoDates, width = 12, text = "Start Date: ", font = fsb).grid(row = 8, column = 0, padx = 5, sticky = "w")
        ttk.Label(stationInfoDates, width = 12, text = "End Date: ", font = fsb).grid(row = 9, column = 0, padx = 5, sticky = "w")
               
#        ttk.Label(stationInfo, textvariable = self.slat, font = fsb).grid(row = 2, column = 1, padx = 5, pady = 5, sticky = "e")
     
        
        ttk.Label(channelInfo, width = 20, text = "Channel Info", font = fst).grid(row = 0, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfo, width = 20, text = "Code: ", font = fsb).grid(row = 1, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfo, width = 20, text = "Location Code: ", font = fsb).grid(row = 2, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfo, width = 20, text = "Latitude  ("+ self.degS + "): ", font = fsb).grid(row = 3, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfo, width = 20, text = "Longitude ("+ self.degS + "): ", font = fsb).grid(row = 4, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfo, width = 20, text = "Elevation (m): ", font = fsb).grid(row = 5, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfo, width = 20, text = "Depth (m): ", font = fsb).grid(row = 6, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfo, width = 20, text = "Azimuth ("+ self.degS + "): ", font = fsb).grid(row = 7, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfo, width = 20, text = "Dip ("+ self.degS + "): ", font = fsb).grid(row = 8, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfo, width = 20, text = "Instrument Type\n(e.g., Geophysical): ", font = fsb).grid(row = 9, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfo, width = 20, text = "Sample Rate (Hz): ", font = fsb).grid(row = 10, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfo, width = 20, text = "Sensor Description: ", font = fsb).grid(row = 11, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfo, width = 20, text = "Datalogger Description: ", font = fsb).grid(row = 12, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfo, width = 20, text = "Sensor Serial Number: ", font = fsb).grid(row = 13, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfo, width = 20, text = "Datalogger Serial Number: ", font = fsb).grid(row = 14, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfo, width = 20, text = "Device ID: ", font = fsb).grid(row = 15, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfo, width = 20, text = "Attached Response File? ", font = fsb).grid(row = 16, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfoDates, text = "Start Date:", font = fsb).grid(row = 17, column = 0, padx = 5, sticky = "w")
        ttk.Label(channelInfoDates, text = "End Date:", font = fsb).grid(row = 18, column = 0, padx = 5, sticky = "w")
       
        labs = 'Year:','Month:','Day:','Hour:','Minute:','Second:'
        cnt = 0
        
        #   Entry boxes - station
        self.sent1 = tk.Entry(stationInfo, textvariable = self.sentv1, width = 20, font = 14)
        self.sent1.grid(row = 1, column = 1, sticky = 'w')
        self.sent2 = tk.Entry(stationInfo, textvariable = self.sentv2, width = 20, font = 14)
        self.sent2.grid(row = 2, column = 1, sticky = 'w')
        self.sent3 = tk.Entry(stationInfo, textvariable = self.sentv3, width = 20, font = 14)
        self.sent3.grid(row = 3, column = 1, sticky = 'w')
        self.sent4 = tk.Entry(stationInfo, textvariable = self.sentv4, width = 20, font = 14)
        self.sent4.grid(row = 4, column = 1, sticky = 'w')
        self.sent5 = tk.Entry(stationInfo, textvariable = self.sentv5, width = 75, font = 14)
        self.sent5.grid(row = 5, column = 1, sticky = 'w')
        self.sent6 = tk.Entry(stationInfo, textvariable = self.sentv6, width = 75, font = 14)
        self.sent6.grid(row = 6, column = 1, sticky = 'w')
        
            
        #   start/end/creation dates
        for i in range(1,13,2):
            if cnt < 6:
                lab1 = tk.Label(stationInfoDates, width = 6, text = labs[cnt], font = 14)
                lab1.grid(row = 7, column = i, padx = 5, sticky = 'w')
                lab2 = tk.Label(stationInfoDates, width = 6, text = labs[cnt], font = 14)
                lab2.grid(row = 8, column = i, padx = 5, sticky = 'w')
                lab3 = tk.Label(stationInfoDates, width = 6, text = labs[cnt], font = 14)
                lab3.grid(row = 9, column = i, padx = 5, sticky = 'w')
            cnt += 1
            
        self.sdent1y = tk.Entry(stationInfoDates, textvariable = self.sdentv1y, width = 6, font = 14)
        self.sdent1y.grid(row = 7, column = 2, padx = 2, sticky = 'w')
        self.sdent1m = tk.Entry(stationInfoDates, textvariable = self.sdentv1m, width = 6, font = 14)
        self.sdent1m.grid(row = 7, column = 4, padx = 2, sticky = 'w')
        self.sdent1d = tk.Entry(stationInfoDates, textvariable = self.sdentv1d, width = 6, font = 14)
        self.sdent1d.grid(row = 7, column = 6, padx = 2, sticky = 'w')
        self.sdent1H = tk.Entry(stationInfoDates, textvariable = self.sdentv1H, width = 6, font = 14)
        self.sdent1H.grid(row = 7, column = 8, padx = 2, sticky = 'w')
        self.sdent1M = tk.Entry(stationInfoDates, textvariable = self.sdentv1M, width = 6, font = 14)
        self.sdent1M.grid(row = 7, column = 10, padx = 2, sticky = 'w')
        self.sdent1S = tk.Entry(stationInfoDates, textvariable = self.sdentv1S, width = 6, font = 14)
        self.sdent1S.grid(row = 7, column = 12, padx = 2, sticky = 'w')
        
        self.sdent2y = tk.Entry(stationInfoDates, textvariable = self.sdentv2y, width = 6, font = 14)
        self.sdent2y.grid(row = 8, column = 2, padx = 2, sticky = 'w')
        self.sdent2m = tk.Entry(stationInfoDates, textvariable = self.sdentv2m, width = 6, font = 14)
        self.sdent2m.grid(row = 8, column = 4, padx = 2, sticky = 'w')
        self.sdent2d = tk.Entry(stationInfoDates, textvariable = self.sdentv2d, width = 6, font = 14)
        self.sdent2d.grid(row = 8, column = 6, padx = 2, sticky = 'w')
        self.sdent2H = tk.Entry(stationInfoDates, textvariable = self.sdentv2H, width = 6, font = 14)
        self.sdent2H.grid(row = 8, column = 8, padx = 2, sticky = 'w')
        self.sdent2M = tk.Entry(stationInfoDates, textvariable = self.sdentv2M, width = 6, font = 14)
        self.sdent2M.grid(row = 8, column = 10, padx = 2, sticky = 'w')
        self.sdent2S = tk.Entry(stationInfoDates, textvariable = self.sdentv2S, width = 6, font = 14)
        self.sdent2S.grid(row = 8, column = 12, padx = 2, sticky = 'w')
        
        self.sdent3y = tk.Entry(stationInfoDates, textvariable = self.sdentv3y, width = 6, font = 14)
        self.sdent3y.grid(row = 9, column = 2, padx = 2, sticky = 'w')
        self.sdent3m = tk.Entry(stationInfoDates, textvariable = self.sdentv3m, width = 6, font = 14)
        self.sdent3m.grid(row = 9, column = 4, padx = 2, sticky = 'w')
        self.sdent3d = tk.Entry(stationInfoDates, textvariable = self.sdentv3d, width = 6, font = 14)
        self.sdent3d.grid(row = 9, column = 6, padx = 2, sticky = 'w')
        self.sdent3H = tk.Entry(stationInfoDates, textvariable = self.sdentv3H, width = 6, font = 14)
        self.sdent3H.grid(row = 9, column = 8, padx = 2, sticky = 'w')
        self.sdent3M = tk.Entry(stationInfoDates, textvariable = self.sdentv3M, width = 6, font = 14)
        self.sdent3M.grid(row = 9, column = 10, padx = 2, sticky = 'w')
        self.sdent3S = tk.Entry(stationInfoDates, textvariable = self.sdentv3S, width = 6, font = 14)
        self.sdent3S.grid(row = 9, column = 12, padx = 2, sticky = 'w')
     
#        #   Entery boxes - channel        
        self.cent1 = tk.Entry(channelInfo, textvariable = self.centv1, width = 20, font = 14)
        self.cent1.grid(row = 1, column = 1, sticky = 'w')
        self.cent2 = tk.Entry(channelInfo, textvariable = self.centv2, width = 20, font = 14)
        self.cent2.grid(row = 2, column = 1, sticky = 'w')
        self.cent3 = tk.Entry(channelInfo, textvariable = self.centv3, width = 20, font = 14)
        self.cent3.grid(row = 3, column = 1, sticky = 'w')
        self.cent4 = tk.Entry(channelInfo, textvariable = self.centv4, width = 20, font = 14)
        self.cent4.grid(row = 4, column = 1, sticky = 'w')
        self.cent5 = tk.Entry(channelInfo, textvariable = self.centv5, width = 20, font = 14)
        self.cent5.grid(row = 5, column = 1, sticky = 'w')
        self.cent6 = tk.Entry(channelInfo, textvariable = self.centv6, width = 20, font = 14)
        self.cent6.grid(row = 6, column = 1, sticky = 'w')
        self.cent7 = tk.Entry(channelInfo, textvariable = self.centv7, width = 20, font = 14)
        self.cent7.grid(row = 7, column = 1, sticky = 'w')
        self.cent8 = tk.Entry(channelInfo, textvariable = self.centv8, width = 20, font = 14)
        self.cent8.grid(row = 8, column = 1, sticky = 'w')
        self.cent9 = tk.Entry(channelInfo, textvariable = self.centv9, width = 20, font = 14)
        self.cent9.grid(row = 9, column = 1, sticky = 'w')
        self.cent10 = tk.Entry(channelInfo, textvariable = self.centv10, width = 20, font = 14)
        self.cent10.grid(row = 10, column = 1, sticky = 'w')
        self.cent11 = tk.Entry(channelInfo, textvariable = self.centv11, width = 75, font = 14)
        self.cent11.grid(row = 11, column = 1, sticky = 'w')
        self.cent12 = tk.Entry(channelInfo, textvariable = self.centv12, width = 75, font = 14)
        self.cent12.grid(row = 12, column = 1, sticky = 'w')
        self.cent13 = tk.Entry(channelInfo, textvariable = self.centv13, width = 20, font = 14)
        self.cent13.grid(row = 13, column = 1, sticky = 'w')
        self.cent14 = tk.Entry(channelInfo, textvariable = self.centv14, width = 20, font = 14)
        self.cent14.grid(row = 14, column = 1, sticky = 'w')
        self.cent15 = tk.Entry(channelInfo, textvariable = self.centv15, width = 20, font = 14)
        self.cent15.grid(row = 15, column = 1, sticky = 'w')
        self.responseLab = tk.Label(channelInfo, textvariable = self.respLab, width = 15, font = fsb)
        self.responseLab.grid(row = 16, column = 1, padx = 5, sticky = 'w')
               
        #   start/end/creation dates
        cnt = 0
        for i in range(1,13,2):
            if cnt < 6:
                lab1 = tk.Label(channelInfoDates, width = 6, text = labs[cnt], font = 14)
                lab1.grid(row = 17, column = i, padx = 5, sticky = 'w')
                lab2 = tk.Label(channelInfoDates, width = 6, text = labs[cnt], font = 14)
                lab2.grid(row = 18, column = i, padx = 5, sticky = 'w')
            cnt += 1
        
        self.cdent1y = tk.Entry(channelInfoDates, textvariable = self.cdentv1y, width = 6, font = 14)
        self.cdent1y.grid(row = 17, column = 2, padx = 2, sticky = 'w')
        self.cdent1m = tk.Entry(channelInfoDates, textvariable = self.cdentv1m, width = 6, font = 14)
        self.cdent1m.grid(row = 17, column = 4, padx = 2, sticky = 'w')
        self.cdent1d = tk.Entry(channelInfoDates, textvariable = self.cdentv1d, width = 6, font = 14)
        self.cdent1d.grid(row = 17, column = 6, padx = 2, sticky = 'w')
        self.cdent1H = tk.Entry(channelInfoDates, textvariable = self.cdentv1H, width = 6, font = 14)
        self.cdent1H.grid(row = 17, column = 8, padx = 2, sticky = 'w')
        self.cdent1M = tk.Entry(channelInfoDates, textvariable = self.cdentv1M, width = 6, font = 14)
        self.cdent1M.grid(row = 17, column = 10, padx = 2, sticky = 'w')
        self.cdent1S = tk.Entry(channelInfoDates, textvariable = self.cdentv1S, width = 6, font = 14)
        self.cdent1S.grid(row = 17, column = 12, padx = 2, sticky = 'w')
        
        self.cdent2y = tk.Entry(channelInfoDates, textvariable = self.cdentv2y, width = 6, font = 14)
        self.cdent2y.grid(row = 18, column = 2, padx = 2, sticky = 'w')
        self.cdent2m = tk.Entry(channelInfoDates, textvariable = self.cdentv2m, width = 6, font = 14)
        self.cdent2m.grid(row = 18, column = 4, padx = 2, sticky = 'w')
        self.cdent2d = tk.Entry(channelInfoDates, textvariable = self.cdentv2d, width = 6, font = 14)
        self.cdent2d.grid(row = 18, column = 6, padx = 2, sticky = 'w')
        self.cdent2H = tk.Entry(channelInfoDates, textvariable = self.cdentv2H, width = 6, font = 14)
        self.cdent2H.grid(row = 18, column = 8, padx = 2, sticky = 'w')
        self.cdent2M = tk.Entry(channelInfoDates, textvariable = self.cdentv2M, width = 6, font = 14)
        self.cdent2M.grid(row = 18, column = 10, padx = 2, sticky = 'w')
        self.cdent2S = tk.Entry(channelInfoDates, textvariable = self.cdentv2S, width = 6, font = 14)
        self.cdent2S.grid(row = 18, column = 12, padx = 2, sticky = 'w')        
        
        
        #   Polar Plots
        fig = plt.figure(figsize = (int(w*0.4/96),int(h*0.6/96)))
        ax1 = fig.add_subplot(121, projection = 'polar')
        ax1.plot(0,1)
        ax1.set_theta_zero_location("N")
        ax1.set_theta_direction(-1)
        ax1.set_yticklabels([])
        ax1.set_title("Azimuth", pad = 20, size = 18)
        
        ax2 = fig.add_subplot(122, projection = 'polar')
        ax2.plot(0,1)
        ax2.set_theta_direction(-1)
        ax2.set_theta_zero_location("E")
        ax2.set_thetamin(-90)
        ax2.set_thetamax(90)
        ax2.set_xticks(np.linspace((-1*(np.pi))/2,(np.pi)/2, 13))
        ax2.set_yticklabels([])
        ax2.set_title("Dip", pad = 20, size = 18)
        ax2.set_xticklabels(['-90'+self.degS + '\n(Up)','-75'+self.degS,'-60'+self.degS,'-45'+self.degS,'-30'+self.degS,'-15'+self.degS,'0'+self.degS + "\n(Seafloor)",'15'+self.degS,'30'+self.degS,'45'+self.degS,'60'+self.degS,'75'+self.degS,'90'+self.degS +'\n(Down)'], size = 10)
        
        #   Plot Canvas
        canvas = FigureCanvasTkAgg(fig, master = self.root)
        plot_widget = canvas.get_tk_widget()
        plot_widget.grid(row = 1, column = 0, rowspan = 3)
        
        #   Upload Save button
        save = tk.Button(channelInfoDates, text = "Update Information", command = lambda: saver())
        save['font'] = tkfont.Font(family = "Lucida Grande", size = 18)
        save.configure(state = 'disabled')
        save.grid(row = 19, column = 1, columnspan = 12, padx = 5, pady = 8)
                
        
        
        

    def create_menubar(self):
        """
        Create the menubar for the canvas
        """
        
        self.menubar = tk.Menu(self.root)
        
        self.filemenu = tk.Menu(self.menubar, tearoff = 0)
        self.filemenu.add_command(label = "New Inventory", command = self.new_inventory)
        self.filemenu.add_command(label = "Open Inventory", command = self.open_inventory)
        self.filemenu.add_separator()
        self.filemenu.add_command(label = "Export All", command = self.export_all)
        self.filemenu.add_command(label = "Selective Export", command = self.export_select)
        self.filemenu.add_separator()
        self.filemenu.add_command(label = "Quit", command = self.root.destroy)
        
        self.editmenu = tk.Menu(self.menubar, tearoff = 0)
        self.editmenu.add_command(label = "Edit Current Channel Response", command = lambda: self.change_resp())
        self.editmenu.add_separator()
        self.editmenu.add_command(label = "Add New Station to Network", command = lambda: self.edit_adds())
        self.editmenu.add_command(label = "Add New Channel to Station", command = lambda: self.edit_addc())
        self.editmenu.add_separator()
        self.editmenu.add_command(label = "Duplicate Current Channel", command = lambda: self.duplicateChan())

        self.menubar.add_cascade(label = "File", menu = self.filemenu)
        self.menubar.add_cascade(label = "Edit", menu = self.editmenu)
        self.menubar.entryconfig("Edit", state = "disabled")
        self.root.config(menu = self.menubar)
        
    def new_inventory(self):
        """
        Creates a new inventory either by starting folder or importing XML
        """
        def NewInventory():
            user = creater.get()
            inv = invCode.get()
            
            now = datetime.now()
            
            sta = Station(
                    code = "NEW",
                    latitude = 1,
                    longitude = 2,
                    elevation = 999,
                    creation_date = UTCDateTime(now),
                    site = Site(name = "Brand New Station"))
            
            cha = Channel(
                    code = "ABC",
                    location_code = "",
                    latitude = 1,
                    longitude = 2,
                    elevation = 999,
                    depth = 999,
                    start_date = UTCDateTime(now),
                    azimuth = 0,
                    dip = -90,
                    sample_rate = 999,
                    types = ['NEW INSTRUMENT'],
                    equipments = Equipment(description = 'Description',
                                       serial_number = 'Num123'),
                    sensor = Equipment(description = 'Description',
                                       serial_number = 'Num123'))
            
            newInv = Inventory(
                    networks = [],
                    source = user + ", Ocean Netowrks Canada",
                    created = UTCDateTime(datetime.today()))
            net = Network(
                    code = inv,
                    stations = [])
            
            sta.channels.append(cha)
            newInv.networks.append(net)
            newInv[0].stations.append(sta)
            
            #   Check if there is a folder for this network
            folds = []
            wrote = False
            for root, dirs, files in os.walk(self.curdir + "/_Inventories"):
                folds += dirs
                
                if inv == dirs:
                    newInv.write(self.curdir + "/_Inventories/" + dirs + "/" + str(inv) + ".xml", format = "STATIONXML")
                    wrote = True
            
            if wrote == False:
                os.makedirs(self.curdir + "/_Inventories/" + str(inv))
                newInv.write(self.curdir + "/_Inventories/" + str(inv) + "/" + str(inv) + ".xml", format = "STATIONXML")
            self.workingInv = newInv
            self.var1.set(self.var1.get()+1)
            self.menubar.entryconfig("Edit", state = "normal")
            newEntry.destroy()
            
        
        #   Gets entry for new network and makes directory
        #   Defines pop up
        newEntry = tk.Toplevel()
        newEntry.geometry("250x175")
        
        titFrame = ttk.Frame(newEntry)
        titFrame.grid(row = 1, column = 1, sticky = "w", padx = 5, pady = 5)
        ttk.Label(titFrame, text = "Enter Base Inventory Information").grid(row = 1, column = 1, sticky = "w", padx = 5, pady = 5)
        
        nameFrame = ttk.Frame(newEntry)
        nameFrame.grid(row = 2, column = 1, sticky = "e", padx = 5, pady = 5)
        ttk.Label(nameFrame, text = 'Creator Name: ').grid(row = 1, column = 1, sticky = "w", padx = 5, pady = 5)
        creater = ttk.Entry(nameFrame, width = 15)
        creater.grid(row = 1, column = 2, sticky = "e")
        
        invFrame = ttk.Frame(newEntry)
        invFrame.grid(row = 3, column = 1, sticky = "e", padx = 5, pady = 5)
        ttk.Label(invFrame, text = 'New Inventory Code: ').grid(row = 1, column = 1, sticky = "w", padx = 5, pady = 5)   
        invCode = ttk.Entry(invFrame, width = 15)
        invCode.grid(row = 1, column = 2, sticky = "e")       
        
        getButt = ttk.Frame(newEntry)
        getButt.grid(row = 4, column = 1, sticky = "e", padx = 5, pady = 5)
        
        ttk.Button(getButt, text = "Create", command = NewInventory, width = 15).pack()
        

    def open_inventory(self):
        #   Define progress bar
        #   Create download bar
        downPop = tk.Toplevel()
        downPop.attributes('-topmost', 'true')
        downPop.geometry('300x100')
        downPop.geometry('+%d+%d' % (((self.dw/2)-(250)),((self.dh/2) - (75)))) 
        downPop.withdraw()
        
        downProg = ttk.Progressbar(downPop, orient = tk.HORIZONTAL, length = 250, mode = 'determinate')
        downProg.pack(side = tk.TOP, padx = 5, pady = 10)
        
        downLabel = tk.Label(downPop, text = "Opening Inventory File")
        downLabel.pack(side = tk.TOP, padx = 5, pady = 10)
        downPop.update_idletasks()
        
        #   Check if there are pre-existing inventories
        folds = []       
        for root, dirs, files in os.walk(self.curdir + "/_Inventories"):
            folds += dirs
            
        if len(folds) == 0:
            tkm.showwarning(title = "No Inventory Folders", message = "There are no inventory directories.\nPlease make a new inventory.", parent = self.root, icon = "warning")
        else:
            XML_inv = tkf.askopenfilename(
                    initialdir = self.curdir + "/_Inventories", 
                    title="Select Station Inventory", 
                    filetypes=(("XML Files", ".xml"), ("All Files", "*.*")))
            downPop.deiconify()
            downProg['value'] = 0
            downLabel.configure(text = "...")
            downPop.update_idletasks()
            time.sleep(0.1)
            
            downProg['value'] = 5
            downLabel.configure(text = "Reading In Inventory")
            downPop.update_idletasks()
            
            obsRead = read_inventory(XML_inv)
            
            downProg['value'] = 100
            downLabel.configure(text = "Done!")
            downPop.update_idletasks()
            downPop.destroy()

            self.workingInv = obsRead
            self.menubar.entryconfig("Edit", state = "normal")
            self.var1.set(self.var1.get()+1)
  

    def edit_addc(self):
        def saver():
            statwrk = availstats.get()
            statlist = self.workingInv[0].get_contents()
            
            tcon = [i for i, s in enumerate(statlist['stations']) if statwrk in s]
            
            now = datetime.now()
            
            cha = Channel(
                    code = "ABC",
                    location_code = "",
                    latitude = 1,
                    longitude = 2,
                    elevation = 999,
                    depth = 999,
                    start_date = UTCDateTime(now),
                    azimuth = 0,
                    dip = -90,
                    sample_rate = 999,
                    types = ['NEW INSTRUMENT'],
                    equipments = Equipment(description = 'Description',
                                       serial_number = 'Num123'),
                    sensor = Equipment(description = 'Description',
                                       serial_number = 'Num123'))
            
            self.workingInv[0][tcon[0]].channels.append(cha)
            self.var1.set(self.var1.get()+1)
            oneAdd.destroy()
            
            
        #   Define the window 

        oneAdd = tk.Toplevel()
        oneAdd.resizable()
        
        statlist = self.workingInv[0].get_contents()
        
        editFrame = tk.LabelFrame(oneAdd, font = 14, text = 'Choose a Station To Add to:', relief = tk.RIDGE)
        editFrame.pack(side = tk.TOP, padx = 5, pady = 5)
        
        availstats = ttk.Combobox(editFrame, values = statlist['stations'], font = 14)
        availstats.current(0)
        availstats.pack(side = tk.LEFT, padx = 5, pady = 5)
        
        adder = tk.Button(editFrame, text = 'Add To Station', command = lambda: saver())
        adder['font'] = tkfont.Font(family = 'Lucinda Grande', size = 12)
        adder.pack(side = tk.RIGHT, padx = 5, pady = 5)
        
        
    def change_resp(self):
        
        self.sensChoice = []
        self.datChoice = []
        
        self.nrlSensDict = self.nrl.sensors
        self.nrlDatDict = self.nrl.dataloggers
        
        self.TempSensResp = []
        self.TempDatResp = []
        
        
        self.ActiveSensorResp = []
        self.ActiveDatlogResp = []
        
        labts = tk.StringVar()
        labts.set("Your Current Sensor Selection is:")
        
        labtd = tk.StringVar()
        labtd.set("Your Current Datalogger Selection is:")
        
        labFile1 = tk.StringVar()
        labFile1.set("No File Chosen")
        
        labFile2 = tk.StringVar()
        labFile2.set("No File Chosen")
        
        labFile3 = tk.StringVar()
        labFile3.set("No File Chosen")
  
        check1 = tk.IntVar()
        check1.set(0)
        check2 = tk.IntVar()
        check1.set(0)
        
        
        def get_response(file):
            if file == 1:
                temp_Sens = tkf.askopenfilename( 
                                title="Select Response File", 
                                filetypes=(("XML Files", ".xml"), ("Text Files", ".txt"), ("All Files", "*.*")))
                
                labFile1.set(temp_Sens)
                try:
                    dl_resp = read_inventory(temp_Sens, format='RESP')[0][0][0].response
                    ent_label1.configure(textvariable = labFile1)
                except:
                    try:
                        dl_resp = read_inventory(temp_Sens, format='STATIONXML')[0][0][0].response
                        ent_label1.configure(textvariable = labFile1)
                    except:
                        tkm.showerror(title = "Response File Error", message = "Invalid File Selection", icon = "error")
                        return
                    
                self.TempSensResp = dl_resp
                self.TempDatResp = dl_resp
            
                print(self.TempSensResp)
                sav1.set(True)
                sav2.set(True)
                
            
            elif file == 2:
                temp_Sens = tkf.askopenfilename(
                                title="Select Response File", 
                                filetypes=(("XML Files", ".xml"), ("Text Files", ".txt"), ("All Files", "*.*")))
                
                labFile2.set(temp_Sens)
                try:
                    dl_resp = read_inventory(temp_Sens, format='RESP')[0][0][0].response
                    ent_label2.configure(textvariable = labFile2)
                except:
                    try:
                        dl_resp = read_inventory(temp_Sens, format='STATIONXML')[0][0][0].response
                        ent_label2.configure(textvariable = labFile2)
                    except:
                        tkm.showerror(title = "Response File Error", message = "Invalid File Selection", icon = "error")
                        return
                    
                self.TempSensResp = dl_resp
                sav1.set(True)

                
            elif file == 3:
                temp_Sens = tkf.askopenfilename(
                                title="Select Response File", 
                                filetypes=(("XML Files", ".xml"), ("Text Files", ".txt"), ("All Files", "*.*")))
                
                labFile3.set(temp_Sens)
                try:
                    dl_resp = read_inventory(temp_Sens, format='RESP')[0][0][0].response
                    ent_label3.configure(textvariable = labFile3)
                except:
                    try:
                        dl_resp = read_inventory(temp_Sens, format='STATIONXML')[0][0][0].response
                        ent_label3.configure(textvariable = labFile3)
                    except:
                        tkm.showerror(title = "Response File Error", message = "Invalid File Selection", icon = "error")
                        return
                    
                self.TempDatResp = dl_resp
                sav2.set(True)
                
        
        def get_combo(event, log, t1, lab):
            if log == 1:
                newV = sensCombo.get()
                self.sensChoice.append(newV)
                
                t2 = t1[newV]
                self.nrlSensDict = t2
                if type(t2) != tuple:
                    sensCombo['values'] = list(self.nrlSensDict)
                    sensCombo.current(0)
                else:
                    sensCombo.config(state = tk.DISABLED)
                    sav1.set(True)

                lab.set(lab.get() + '\n' + newV)
                lab1.configure(textvariable = lab)
                
                
            else:
                newV = datCombo.get()
                self.datChoice.append(newV)
                
                t2 = t1[newV]
                self.nrlDatDict = t2
                
                if type(t2) != tuple:
                    datCombo['values'] = list(self.nrlDatDict)
                    datCombo.current(0)
                else:
                    datCombo.config(state = tk.DISABLED)
                    sav2.set(True)
                lab.set(lab.get() + '\n' + newV)
                lab2.configure(text = lab)
                
            
        def redo(inst, lab):
           if inst ==1:
               self.sensChoice = []
               self.nrlSensDict = self.nrl.sensors
               sensCombo['values'] = list(self.nrlSensDict)
               sensCombo.config(state = tk.NORMAL)
               sensCombo.current(0)
               lab.set("Your Current Sensor Selection is:")
               sav1.set(False)
               return
           else:
               self.datChoice = []
               self.nrlDatDict = self.nrl.dataloggers
               datCombo['values'] = list(self.nrlDatDict)
               datCombo.config(state = tk.NORMAL)
               datCombo.current(0)
               lab.set("Your Current Datalogger Selection is:")
               sav2.set(False)
               return
         
        def activeCheck(*args):
            if val1.get() == 0:
                for child in r0.winfo_children():
                    child.configure(state = 'normal')
                for child in sensFrame.winfo_children():
                    child.configure(state = 'disabled')
                for child in datFrame.winfo_children():
                    child.configure(state = 'disabled')
                for child in datFrame.winfo_children():
                    child.configure(state = 'disabled')
                C1.configure(state = 'disabled')
                C2.configure(state = 'disabled')
  
            if val2.get() == 0 and val1.get() == 0:
                for child in r1.winfo_children():
                    child.configure(state = 'normal')
                for child in r2.winfo_children():
                    child.configure(state = 'disabled')
                for child in r3.winfo_children():
                    child.configure(state = 'disabled')
                    
            elif val2.get() == 1 and val1.get() == 0:
                for child in r1.winfo_children():
                    child.configure(state = 'disabled')
                for child in r2.winfo_children():
                    child.configure(state = 'normal')
                for child in r3.winfo_children():
                    child.configure(state = 'normal')
                    
            elif val1.get() == 1:
                for child in r0.winfo_children():
                    child.configure(state = 'disabled')
                for child in r1.winfo_children():
                    child.configure(state = 'disabled')
                for child in r2.winfo_children():
                    child.configure(state = 'disabled')
                for child in r3.winfo_children():
                    child.configure(state = 'disabled')    
                for child in sensFrame.winfo_children():
                    child.configure(state = 'normal')
                for child in datFrame.winfo_children():
                    child.configure(state = 'normal')
                for child in datFrame.winfo_children():
                    child.configure(state = 'normal')
                C1.configure(state = 'normal')
                C2.configure(state = 'normal')

                    
                if check1.get() == 0:
                    for child in senEntery.winfo_children():
                        child.configure(state = 'disabled')
                        
                elif check1.get() == 1:
                    for child in senEntery.winfo_children():
                        child.configure(state = 'normal')
                        
                if check2.get() == 0:
                    for child in datEntery.winfo_children():
                        child.configure(state = 'disabled')
                elif check2.get() == 1:
                    for child in datEntery.winfo_children():
                        child.configure(state = 'normal')
                        
            if sav1.get() == True and sav2.get() == True:
                saveButt.configure(state = 'normal')
            elif sav1.get() == False or sav2.get() == False:
                saveButt.configure(state = 'disabled')
                     
                
        def saver(check1, check2, val1):
            tempChan = self.chanWork
            
            
            if val1.get() == 0:                   
   

               self.TempDatResp.response_stages.pop(0)
               self.TempDatResp.response_stages.insert(0, self.TempSensResp.response_stages[0])
               self.TempDatResp.instrument_sensitivity.input_units = self.TempSensResp.instrument_sensitivity.input_units
               self.TempDatResp.instrument_sensitivity.input_units_description = self.TempSensResp.instrument_sensitivity.input_units_description
               _response = self.TempDatResp
   
               if _response.instrument_sensitivity.output_units=="COUNTS" or _response.instrument_sensitivity.output_units == "COUNT":
                   _response.instrument_sensitivity.output_units = _response.instrument_sensitivity.output_units.lower()
               if _response.instrument_sensitivity.input_units=="COUNTS" or _response.instrument_sensitivity.input_units == "COUNT":
                   _response.instrument_sensitivity.input_units = _response.instrument_sensitivity.input_units.lower()

               for stage in _response.response_stages:
                   #correct for COUNTS units name
                   if stage.output_units=="COUNTS" or stage.output_units=="COUNT":
                       stage.output_units = stage.output_units.lower()
                       stage.output_units_description = "Digital Counts"
                   if stage.input_units=="COUNTS" or stage.output_units=="COUNT":
                       stage.input_units = stage.input_units.lower()
                       stage.input_units_description = "Digital Counts"
               #correct for Celsius (C) units name
               if stage.output_units=="C":
                   stage.output_units = "degC"
               if stage.input_units=="C":
                   stage.input_units = "degC"
                   
               try:
                   if _response[0][0][0]["_equipment_serial"][0].endswith("40Vpg"):
                       for stage in _response.response_stages:
                           if stage.stage_gain == 1 and stage.input_units == 'counts' and stage.output_units == 'counts':
                               stage.stage_gain = stage.stage_gain * float(2/3)
                               break
               except:
                   pass
               
               tempChan[0][0][0].response = _response
               self.chanWork = tempChan
               self.workingInv[0][self.tcon[0]][self.tcha[0]].response = _response
               self.var1.set(self.var1.get()+1)
               respEdit.destroy()


            if val1.get() != 0:
                built_response = self.nrl.get_response(self.sensChoice, self.datChoice)

            
                if check1.get() == 1:
                    try:
                        sen_coef = float(ent1.get())
                    except:
                        tkm.showerror(title = "Sensor Coefficient Error", message = "Invalid Coefficient", icon = "error")
                        return
                    
                    if tempChan['chan'][0][0][0].code.endswith('E') or tempChan['chan'][0][0][0].code.endswith('2'):
                        built_response.response_stages[0].stage_gain = sen_coef[0]
                    elif tempChan['chan'][0][0][0].code.endswith('N') or tempChan['chan'][0][0][0].code.endswith('1'):
                        built_response.response_stages[0].stage_gain = sen_coef[1]
                    elif tempChan['chan'][0][0][0].code.endswith('Z') or tempChan['chan'][0][0][0].code.endswith('3'):
                        built_response.response_stages[0].stage_gain = sen_coef[2]
                     
                     
                if check2.get() == 1:
                    try:
                        dl_coef = float(ent2.get())
                    except:
                        tkm.showerror(title = "Datalogger Coefficient Error", message = "Invalid Coefficient", icon = "error")
                        return
                
                for stage in built_response.response_stages:
                    if stage.input_units == 'V' and stage.output_units == 'COUNTS':
                        if tempChan['chan'][0][0][0].code.endswith('E') or tempChan['chan'][0][0][0].code.endswith('2'):
                             built_response.response_stages[2].stage_gain = 1/dl_coef[0]
                        elif tempChan['chan'][0][0][0].code.endswith('N') or tempChan['chan'][0][0][0].code.endswith('1'):
                             built_response.response_stages[2].stage_gain = 1/dl_coef[1]
                        elif tempChan['chan'][0][0][0].code.endswith('Z') or tempChan['chan'][0][0][0].code.endswith('3'):
                             built_response.response_stages[2].stage_gain = 1/dl_coef[2]
            
                try:
                    built_response.recalculate_overall_sensitivity()
                except:
                    tkm.showwarning(title = 'Response Recalculation', message = 'Unable to recalculate sensitivty. Moving on', icon = 'warning')
                
                tempChan[0][0][0].response = built_response

                self.chanWork = tempChan
                self.workingInv[0][self.tcon[0]][self.tcha[0]].response = _response
                self.var1.set(self.var1.get()+1)
                respEdit.destroy()

             

        
        
            
        respEdit = tk.Toplevel()
        respEdit.resizable()
        respEdit.attributes('-topmost', True)
        
        val1 = tk.IntVar()
        val2 = tk.IntVar()
        sav1 = tk.BooleanVar()
        sav2 = tk.BooleanVar()
        sav1.set(False)
        sav2.set(False)
        
        e1 = tk.Frame(respEdit)
        ttk.Radiobutton(e1, text = 'Choose from File', variable = val1, value = 0).pack(side = tk.LEFT, padx = 5, pady = 5, anchor = 'w')
        ttk.Radiobutton(e1, text = 'Manually Generate Response', variable = val1, value = 1).pack(side = tk.RIGHT, padx = 5, pady = 5, anchor = 'w')
        e1.pack(side = tk.TOP, padx = 5, pady = 5)
        
        #   File method
        fileFrame = tk.LabelFrame(respEdit, font = 14, text = "Choose Response from File", relief = tk.RIDGE)
        fileFrame.pack(side = tk.TOP, padx = 5, pady = 5)
        
        r0 = tk.Frame(fileFrame)
        ttk.Radiobutton(r0, text = 'Sensor and Datalogger Responses Match', variable = val2, value = 0).pack(side = tk.TOP, padx = 5, pady = 5, anchor = 'w')
        ttk.Radiobutton(r0, text = 'Sensor and Datalogger Responses Differ', variable = val2, value = 1).pack(side = tk.TOP, padx = 5, pady = 5, anchor = 'w')

        r0.pack(side = tk.TOP, padx = 5, pady = 5)
        
        r1 = tk.Frame(fileFrame)
        tk.Label(r1, text = "Choose Sensor/Datalogger File: ", font = 11, anchor = 'w').pack(side = tk.LEFT, padx = 5, pady = 5, anchor = 'w')
        entR_Match = tk.Button(r1, text = "Choose File...", command = lambda: get_response(1))
        ent_label1 = tk.Label(r1, width = 20, textvariable = labFile1, font = 11, anchor = 'w')
        entR_Match.pack(side = tk.LEFT, padx = 5, pady = 5, anchor = 'w')
        ent_label1.pack(side = tk.LEFT, padx = 5, pady = 5, anchor = 'w')
        r1.pack(side = tk.TOP, padx = 5, pady = 5)
        
        r2 = tk.Frame(fileFrame)
        tk.Label(r2, text = "Choose Sensor Response File: ", font = 11, anchor = 'w').pack(side = tk.LEFT, padx = 5, pady = 5, anchor = 'w')
        entR_Match = tk.Button(r2, text = "Choose File...", command = lambda: get_response(2))
        ent_label2 = tk.Label(r2, width = 20, textvariable = labFile2, font = 11, anchor = 'w')
        entR_Match.pack(side = tk.LEFT, padx = 5, pady = 5)
        ent_label2.pack(side = tk.LEFT, padx = 5, pady = 5)
        r2.pack(side = tk.TOP, padx = 5, pady = 5)
        
        r3 = tk.Frame(fileFrame)
        tk.Label(r3, text = "Choose Datalogger Response File: ", font = 11, anchor = 'w').pack(side = tk.LEFT, padx = 5, pady = 5, anchor = 'w')
        entR_Match = tk.Button(r3, text = "Choose File...", command = lambda: get_response(3))
        ent_label3 = tk.Label(r3, width = 20, textvariable = labFile3, font = 11, anchor = 'w')
        entR_Match.pack(side = tk.LEFT, padx = 5, pady = 5)
        ent_label3.pack(side = tk.LEFT, padx = 5, pady = 5)
        r3.pack(side = tk.TOP, padx = 5, pady = 5)


        manFrame = tk.LabelFrame(respEdit, font = 14, text = "Manually Enter Using National Response Library (NRL)", relief = tk.RIDGE)
        manFrame.pack(side = tk.TOP, padx = 5, pady = 5)
        
        sensFrame = tk.LabelFrame(manFrame, font = 14, text = "Sensor", relief = tk.RIDGE)
        sensFrame.pack(side = tk.TOP, padx = 5, pady = 5, fill = tk.X)
        
        sensCombo = ttk.Combobox(sensFrame, values = list(self.nrlSensDict))
        sensCombo.bind("<<ComboboxSelected>>", lambda event: get_combo(event, 1, self.nrlSensDict, labts))
        sensCombo.current(0)
        sensCombo.pack(side = tk.LEFT, padx = 5, pady = 5)
        
        lab1 = tk.Label(sensFrame, textvariable = labts, font = 11, anchor = 'w')
        lab1.pack(side = tk.LEFT, padx = 5, pady = 5)
        
        restButt1 = tk.Button(sensFrame, text = 'Reset', command = lambda: redo(1, labts))
        restButt1.pack(side = tk.RIGHT, padx = 5, pady = 5)
        
        datFrame = tk.LabelFrame(manFrame, font = 14, text = "Datalogger", relief = tk.RIDGE)
        datFrame.pack(side = tk.TOP, padx = 5, pady = 5, fill = tk.X)
        
        datCombo = ttk.Combobox(datFrame, values = list(self.nrlDatDict))
        datCombo.bind("<<ComboboxSelected>>", lambda event: get_combo(event, 2, self.nrlDatDict, labtd))
        datCombo.current(0)
        datCombo.pack(side = tk.LEFT, padx = 5, pady = 5)
        
        lab2 = tk.Label(datFrame, textvariable = labtd, font = 11, anchor = 'w')
        lab2.pack(side = tk.LEFT, padx = 5, pady = 5)
        
        restButt2 = tk.Button(datFrame, text = 'Reset', command = lambda: redo(2, labtd))
        restButt2.pack(side = tk.RIGHT, padx = 5, pady = 5)
        
        calCheck = tk.Frame(manFrame)
        calCheck.pack(side = tk.TOP, padx = 5, pady = 5, fill = tk.X)
        
        calFrame = tk.LabelFrame(manFrame, font = 14, text = 'Calibrations', relief = tk.RIDGE)
        calFrame.pack(side = tk.TOP, padx = 5, pady = 5, fill = tk.X)
        
        
        sencal = tk.Frame(calFrame)
        sencal.pack(side = tk.LEFT, padx = 5, pady = 5)
        
        datcal = tk.Frame(calFrame)
        datcal.pack(side = tk.RIGHT, padx = 5, pady = 5)
        
        senEntery = tk.Frame(sencal)
        senEntery.pack(side = tk.RIGHT, padx = 5, pady = 5)
        
        datEntery = tk.Frame(datcal)
        datEntery.pack(side = tk.RIGHT, padx = 5, pady = 5)
        
        senLabel = tk.Frame(sencal)
        senLabel.pack(side = tk.LEFT, padx = 5, pady = 5)
        
        datLabel = tk.Frame(datcal)
        datLabel.pack(side = tk.LEFT, padx = 5, pady = 5)
        
        C1 = tk.Checkbutton(calCheck, text = "Manually Enter Sensor Calibrations", variable = check1, command = lambda: activeCheck())
        C1.pack(side = tk.LEFT, padx = 5, pady = 5)
        C2 = tk.Checkbutton(calCheck,  text = "Manually Enter Datalogger Calibrations", variable = check2, command = lambda: activeCheck())
        C2.pack(side = tk.RIGHT, padx = 5, pady = 5)        
        
        saveButt = tk.Button(respEdit, text = 'Save', command = lambda: saver(check1, check2, val1))
        saveButt['font'] = tkfont.Font(family = "Lucida Grande", size = 18)
        saveButt.configure(state = 'disabled')
        saveButt.pack(side = tk.TOP, padx = 5, pady = 5)
        
        label = ['Stage Gain'] 
    
        lab = tk.Label(senLabel, width = 10, text = label, font = 11, anchor = "w")
        ent1 = tk.Entry(senEntery, width = 10, font = 11)
        ent1.configure(state = 'disabled')
        lab.pack(side = tk.TOP)
        ent1.pack(side = tk.TOP, expand = tk.YES)

        lab = tk.Label(datLabel, width = 10, text = label, font = 11, anchor = "w")
        ent2 = tk.Entry(datEntery, width = 10, font = 11)
        ent2.configure(state = 'disabled')
        lab.pack(side = tk.TOP)
        ent2.pack(side = tk.TOP, expand = tk.YES)
        
        val1.trace('w', activeCheck)
        val2.trace('w', activeCheck)
        sav1.trace('w', activeCheck)
        sav2.trace('w', activeCheck)


        
        
    def edit_adds(self):
        def NewStatSave():
            lstr = self.workingInv[0].get_contents()
            newStat = name.get()
            
            if (' ' in newStat) or (newStat == None) or len(newStat) > 5:
                tkm.showwarning(title = "Station - Invalid Entry", message = "Invalid Station Entry.\nPlease follow SEED Guidlines", parent = self.root, icon = "warning")
                return
            
            if any(newStat.upper() in name for name in lstr['stations']):
                tkm.showwarning(title = "Station - Invalid Entry", message = "Station Already Exists.\nPlease Choose a Different Code", parent = self.root, icon = "warning")
                return
            
            now = datetime.now()
            
            sta = Station(
                    code = newStat.upper(),
                    latitude = 1,
                    longitude = 2,
                    elevation = 999,
                    creation_date = UTCDateTime(now),
                    site = Site(name = "Brand New Station"))
            
            cha = Channel(
                    code = "ABC",
                    location_code = "",
                    latitude = 1,
                    longitude = 2,
                    elevation = 999,
                    depth = 999,
                    start_date = UTCDateTime(now),
                    azimuth = 0,
                    dip = -90,
                    sample_rate = 999,
                    types = ['NEW INSTRUMENT'],
                    equipments = Equipment(description = 'Description',
                                       serial_number = 'Num123'),
                    sensor = Equipment(description = 'Description',
                                       serial_number = 'Num123'))
            
            sta.channels.append(cha)
            self.var1.set(self.var1.get()+1)            
            self.workingInv[0].stations.append(sta)
            self.var1.set(self.var1.get()+1)
            addstat.destroy()
            
            
        
        
        addstat = tk.Toplevel()
        addstat.resizable()
        
        statFrame = tk.LabelFrame(addstat, font = 12, text = "Enter New Station Code", relief = tk.RIDGE)
        statFrame.pack(side = tk.TOP, padx = 5, pady = 5)
        
        name = tk.Entry(statFrame, width = 10, font = 12)
        name.pack(side = tk.LEFT, padx = 5, pady = 5)
        
        ent = tk.Button(statFrame, text = 'Add', command = lambda : NewStatSave())
        ent['font'] = tkfont.Font(family = 'Lucinda Grande', size = 12)
        ent.pack(side = tk.RIGHT, padx = 5, pady = 5)
        
    def duplicateChan(self):
        
        ask = tkm.askyesno(title = "Channel - Duplicate Selection", message = "Do you wish to duplicate the currently selected channel?", icon = "warning")
        
        if ask == True:
            temp = self.chanWork.copy()
            temp[0][0][0].code = 'DUPL'
            self.workingInv[0].stations[self.tcon[0]].channels.append(temp[0][0][0])
            self.var1.set(self.var1.get()+1)    
        else:
            return           

    def export_all(self):
        def saveEx():
            sv = tkf.asksaveasfilename(defaultextension = '.xml',
                                       title="Select response file", 
                                       filetypes=(("XML Files", ".xml"), ("all files", "*.*")))
            
            if sv is None:
                return
            
            self.workingInv.created = UTCDateTime(datetime.now())
            self.workingInv.source = str(name.get()) + ', Ocean Networks Canada'
            self.workingInv.write(sv, format = "STATIONXML")
            exAll.destroy()

            
            
        
        exAll = tk.Toplevel()
        exAll.resizable()
        
        exFrame = tk.LabelFrame(exAll, font = 12, text = 'Export all', relief = tk.RIDGE)
        exFrame.grid(row = 0, column = 0, padx = 5, pady = 5)
        
        namelab = tk.Label(exFrame, text = 'Creator: ')
        namelab.grid(row = 0, column = 0, padx = 5, pady = 5)
        
        name = tk.Entry(exFrame, width = 10, font = 12)
        name.grid(row = 0, column = 1, padx = 5, pady = 5)
        
        exBut = tk.Button(exFrame, text = 'Save', command = lambda: saveEx())
        exBut.grid(row = 1, column = 0, columnspan = 2, padx = 5, pady = 5)
        
    def export_select(self):
        def selective_saveas(station, location, channel, starttime, endtime, creator):
            
            if endtime != "*":
                try:
                    endtime = UTCDateTime(endtime)
                except:
                    tkm.showinfo(title="Invalid End Time", 
                                        message="Invalid 'endtime' provided. Must at least provide the year-month-day (e.g., 2010-01-01).")
                    return
                
            if starttime != "*":
                try:
                    starttime = UTCDateTime(starttime)
                except:
                    tkm.showinfo(title="Invalid Start Time", 
                                        message="Invalid 'starttime' provided. Must at least provide the year-month-day (e.g., 2010-01-01).")
                    return
                    
            sel_inv = self.workingInv.select(station=station, 
                                      location=location, 
                                      channel=channel, 
                                      starttime=starttime, 
                                      endtime=endtime)
            
            sel_inv = sel_inv.copy()
            
            if sel_inv.networks == []: #empty
                tkm.showinfo(title="Empty Inventory", 
                                    message="Parameter selection resulted in empty Inventory! \n\n{}\nStation: {}\nLocation: {}\nChannel: {}\nStart Time: {}\nEnd Time: {}\n\nFile NOT saved.".format(self.workingInv[0].code, station, location, channel, starttime, endtime))
                return
            else:
                filename = tkf.asksaveasfilename(
                        title="Select response file", 
                        filetypes=(("XML Files", ".xml"), ("All Files", "*.*")))
                if filename is None:
                    return
                else:
                    sel_inv.created = UTCDateTime(datetime.now())
                    sel_inv.source = str(creator) + ', Ocean Networks Canada'
                    sel_inv.write(filename + '.xml', format="STATIONXML")
                    popup.destroy()

            
        if self.workingInv == "":
            return
        
        else:
            popup = tk.Toplevel()
            popup.grab_set()
            popup.title("Append to Inventory")
            
            lf = tk.LabelFrame(master=popup, text="Parameter Selection")
            lf.pack()
            
            tk.Label(lf, text="Station: ", justify="right").grid(row=1, column=1, sticky="e", padx=2, pady=5)
            stationEntry = tk.Entry(master=lf)
            stationEntry.grid(row=1, column=2, sticky="w")
            stationEntry.insert(tk.END, "*")
            
            tk.Label(lf, text="Location: ", justify="right").grid(row=2, column=1, sticky="e", padx=2, pady=5)
            locationEntry = tk.Entry(master=lf)
            locationEntry.grid(row=2, column=2, sticky="w")
            locationEntry.insert(tk.END, "*")
            
            tk.Label(lf, text="Channel: ", justify="right").grid(row=3, column=1, sticky="e", padx=2, pady=5)
            channelEntry = tk.Entry(master=lf)
            channelEntry.grid(row=3, column=2, sticky="w")
            channelEntry.insert(tk.END, "*")
            
            tk.Label(lf, text="Start Time: ", justify="right").grid(row=4, column=1, sticky="e", padx=2, pady=5)
            starttimeEntry = tk.Entry(master=lf)
            starttimeEntry.grid(row=4, column=2, sticky="w")
            starttimeEntry.insert(tk.END, "*")
        
            tk.Label(lf, text="End Time: ", justify="right").grid(row=5, column=1, sticky="e", padx=2, pady=5)
            endtimeEntry = tk.Entry(master=lf)
            endtimeEntry.grid(row=5, column=2, sticky="w")
            endtimeEntry.insert(tk.END, "*")
            
            tk.Label(lf, text="Creator: ", justify="right").grid(row=6, column=1, sticky="e", padx=2, pady=5)
            createEntry = tk.Entry(master=lf)
            createEntry.grid(row=6, column=2, sticky="w")
            createEntry.insert(tk.END, "*")
            
            b = tk.Button(master=lf, text="Save As", command=lambda: selective_saveas(station=stationEntry.get(), 
                                                                              location=locationEntry.get(), 
                                                                              channel=channelEntry.get(), 
                                                                              starttime=starttimeEntry.get(), 
                                                                              endtime=endtimeEntry.get(),
                                                                              creator=createEntry.get()))
            b.grid(row=7, column=1, sticky="w", padx=2, pady=5)
    



def main():
    app = ExcelXML("")
    app.root.mainloop()
    
if __name__ == '__main__':
    main()            
        
        